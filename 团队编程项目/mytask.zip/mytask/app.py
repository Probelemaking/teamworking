from datetime import datetime
from flask import Flask, request
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from sqlalchemy import text

app = Flask(__name__)

# 配置信息
HOSTNAME = "127.0.0.1"
PORT = 3306
USERNAME = "root"
PASSWORD = "123456"
DATABASE = "food"
app.config[
    'SQLALCHEMY_DATABASE_URI'] = f"mysql+pymysql://{USERNAME}:{PASSWORD}@{HOSTNAME}:{PORT}/{DATABASE}?charset=utf8mb4"

# 在app.config中设置好连接数据库的信息
# 然后再sqlalchemy(app)中创建一个db对象，他会自动读取连接数据库的配置信息
db = SQLAlchemy(app)
migrate = Migrate(app, db)


# ORM模型映射成表的三步
# 1. flask db init：这步只需要执行一次
# 2. flask db migrate：识别ORM模型的改变，生成迁移脚本
# 3. flask db upgrade：运行迁移脚本，同步到数据库中


class Food(db.Model):
    __tablename__ = "food"
    food_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    # varchar, null=0
    food_name = db.Column(db.String(40), nullable=False)
    food_loc = db.Column(db.String(100), nullable=False)
    food_type = db.Column(db.Integer, server_default=text('0'))
    food_src = db.Column(db.String(100))
    food_likes_num = db.Column(db.Integer, server_default=text('0'))
    food_brief_description = db.Column(db.String(255))
    create_time = db.Column(db.DateTime, default=datetime.now)
    update_time = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)
    # create_time = db.Column(db.DateTime, server_default=datetime.datetime.now)
    # update_time =  db.Column(db.DateTime, server_default=datetime.datetime.now, onupdate=datetime.datetime.now)


# user = User(username="法外狂徒张三", password='111111')
# sql: insert user(username, password) values('法外狂徒张三', '111111');


class User(db.Model):
    __tablename__ = "user"
    user_name = db.Column(db.String(20), primary_key=True)
    user_account = db.Column(db.String(20), nullable=False)
    user_password = db.Column(db.String(30), nullable=False)
    user_head = db.Column(db.String(255))
    user_sex = db.Column(db.SmallInteger)  # 0为男，1为女
    user_age = db.Column(db.SmallInteger)


class Comments(db.Model):
    __tablename__ = "comments"
    comments_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_name = db.Column(db.String(20), db.ForeignKey("user.user_name"))
    food_id = db.Column(db.Integer, db.ForeignKey("food.food_id"))
    comments = db.Column(db.Text, nullable=False)
    comments_src1 = db.Column(db.String(100))
    comments_src2 = db.Column(db.String(100))
    comments_src3 = db.Column(db.String(100))
    comments_grade = db.Column(db.SmallInteger())
    Comments_likes_num = db.Column(db.Integer, server_default=text('5'))
    create_time = db.Column(db.DateTime, default=datetime.now)


class Tag(db.Model):
    __tablename__ = "Tag"
    # 添加外键
    user_name = db.Column(db.String(20), db.ForeignKey("user.user_name"), primary_key=True)
    tag1 = db.Column(db.SmallInteger, server_default=text('0'))
    tag2 = db.Column(db.SmallInteger, server_default=text('0'))
    tag3 = db.Column(db.SmallInteger, server_default=text('0'))
    tag4 = db.Column(db.SmallInteger, server_default=text('0'))
    tag5 = db.Column(db.SmallInteger, server_default=text('0'))
    tag6 = db.Column(db.SmallInteger, server_default=text('0'))
    tag7 = db.Column(db.SmallInteger, server_default=text('0'))
    tag8 = db.Column(db.SmallInteger, server_default=text('0'))


class Collection(db.Model):
    __tablename__ = "collection"
    user_name = db.Column(db.String(20), db.ForeignKey("user.user_name"), primary_key=True)
    food_id = db.Column(db.Integer, db.ForeignKey("food.food_id"), primary_key=True)


class Friends(db.Model):
    __tablename__ = "friends"
    user_name1 = db.Column(db.String(20), db.ForeignKey("user.user_name"), primary_key=True)
    user_name2 = db.Column(db.String(20), db.ForeignKey("user.user_name"), primary_key=True)
    # db.primary_key(user_name1, user_name2)


class Shops(db.Model):
    __tablename__ = "shops"
    shop_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    shop_loc = db.Column(db.String(100), nullable=False)
    shop_name = db.Column(db.String(40), nullable=False)


class ShopsFood(db.Model):
    __tablename__ = "shopsFood"
    shop_id = db.Column(db.Integer, db.ForeignKey("shops.shop_id"), primary_key=True)
    food_id = db.Column(db.Integer, db.ForeignKey("food.food_id"), primary_key=True)

#
# with app.app_context():
#     with db.engine.connect() as conn:
#         rs = conn.execute("select 1")
#         print(rs.fetchone())  # (1,)


@app.route('/user/add_all_data', methods=['POST'])
def add_all_data():
    if request.method == "POST":
        objects = [User(user_name="小红", user_account="1001", user_password="123"),
                   User(user_name="小明", user_account="1002", user_password="123"),
                   User(user_name="小杰", user_account="1003", user_password="123"),
                   User(user_name="小蓝", user_account="1004", user_password="123"),
                   User(user_name="小黑", user_account="1005", user_password="123"),
                   User(user_name="小白", user_account="1006", user_password="123"),
                   User(user_name="小绿", user_account="1007", user_password="123"),
                   # Tag(user_name="小红", tag1=1, tag2=0, tag3=0, tag4=0, tag5=0, tag6=0, tag7=0, tag8=0),
                   # Tag(user_name="小白", tag1=0, tag2=2, tag3=0, tag4=0, tag5=0, tag6=1, tag7=0, tag8=0),
                   # Tag(user_name="小黑", tag1=0, tag2=0, tag3=0, tag4=0, tag5=1, tag6=0, tag7=0, tag8=0),
                   Food(food_id=1, food_name="a", food_loc="食堂1", food_type=1, food_src="https://", food_likes_num=130),
                   Food(food_id=2, food_name="b", food_loc="食堂2", food_type=3, food_src="https://", food_likes_num=13),
                   Food(food_id=3, food_name="c", food_loc="食堂3", food_type=2, food_src="https://", food_likes_num=10),
                   Food(food_id=4, food_name="d", food_loc="食堂4", food_type=2, food_src="https://", food_likes_num=30),
                   Food(food_id=5, food_name="e", food_loc="食堂5", food_type=3, food_src="https://", food_likes_num=20),
                   # Friends(user_name1="小绿", user_name2="小白"),
                   # Friends(user_name1="小白", user_name2="小绿"),
                   # Friends(user_name1="小白", user_name2="小绿"),
                   # Friends(user_name1="小黑", user_name2="小红"),
                   # Collection(user_name="小白", food_id=1),
                   # Collection(user_name="小黑", food_id=2),
                   # Collection(user_name="小绿", food_id=3)
                   ]
        objects1 = [
                   Tag(user_name="小红", tag1=1, tag2=0, tag3=0, tag4=0, tag5=0, tag6=0, tag7=0, tag8=0),
                   Tag(user_name="小白", tag1=0, tag2=1, tag3=0, tag4=0, tag5=0, tag6=1, tag7=0, tag8=0),
                   Tag(user_name="小黑", tag1=0, tag2=0, tag3=0, tag4=0, tag5=1, tag6=0, tag7=0, tag8=0),
                   Friends(user_name1="小绿", user_name2="小白"),
                   Friends(user_name1="小白", user_name2="小绿"),
                   Friends(user_name1="小红", user_name2="小黑"),
                   Friends(user_name1="小黑", user_name2="小红"),
                   Collection(user_name="小白", food_id=1),
                   Collection(user_name="小黑", food_id=2),
                   Collection(user_name="小绿", food_id=3)
                   ]
        try:
            db.session.add_all(objects)
            db.session.commit()
            db.session.add_all(objects1)
            db.session.commit()
            print(1)
            return "数据插入成功！"
        except Exception as e:
            db.session.rollback()
            print(e)
            return "数据插入失败！"


@app.route('/user/add_account', methods=['POST'])
def user_add_account():
    if request.method == "POST":
        name = request.form.get("username")
        account = request.form.get("account")
        password = request.form.get("password")
        user = User(user_name=name, user_account=account, user_password=password)
        try:
            db.session.add(user)
            db.session.commit()
            print(1)
            return "用户创建成功！"
        except Exception as e:
            db.session.rollback()
            print(e)
            return "用户创建失败！"


@app.route('/user/add_tag', methods=['POST'])
def user_add_tag():
    if request.method == "POST":
        name = request.form.get("username")
        name1 = User.query.get(name)
        # print(name1)
        if name1 is None:
            print(-1)
            return "tag插入失败，数据库中无此用户！"
        tag_list = request.form.get("tag_list")
        # tag_list1 = []
        tag = Tag(user_name=name, tag1=int(tag_list[1]), tag2=int(tag_list[3]), tag3=int(tag_list[5]),
                  tag4=int(tag_list[7]), tag5=int(tag_list[9]), tag6=int(tag_list[11]), tag7=int(tag_list[13]),
                  tag8=int(tag_list[15]))
        # for i in tag_list:
        #     print(i)
        # print(tag_list)
        try:
            db.session.add(tag)
            db.session.commit()
            print(1)
            return "tag插入成功！"
        except Exception as e:
            db.session.rollback()
            print(e)
            return "tag插入失败！"


@app.route('/user/likes_nums', methods=['POST'])
def likes_nums():
    if request.method == "POST":
        name = request.form.get("username")
        name1 = User.query.filter_by(user_name=name).first()
        # print(name)
        food_id = request.form.get("food_id")
        food_id1 = Food.query.filter_by(food_id=int(food_id)).first()
        # print(food_id1)
        if food_id1 is None:
            print("-1")
            return "点赞失败，数据库中无此用户！"
        if name1 is None:
            print(-1)
            return "点赞失败，数据库中无此食物！"
        try:
            food_id1.food_likes_num = food_id1.food_likes_num + 1
            db.session.commit()
            return "点赞成功！"
        except Exception as e:
            db.session.rollback()
            print(e)
            return "点赞失败！"


@app.route('/user/collcetion', methods=['POST'])
def collection():
    if request.method == "POST":
        name = request.form.get("username")
        name1 = User.query.filter_by(user_name=name).first()
        food_id = request.form.get("food_id")
        food_id1 = Food.query.filter_by(food_id=int(food_id)).first()
        collections = Collection.query.filter_by(user_name=name)
        if name1 is None:
            print("-1")
            return "收藏失败，数据库中无此用户！"
        if food_id1 is None:
            print(-1)
            return "收藏失败，数据库中无此食物！"
        f = 0
        for collection in collections:
            if collection.food_id == int(food_id):
                f = 1
        if f == 1:
            return "收藏失败，该食物已收藏！"
        try:
            collection = Collection(user_name=name, food_id=int(food_id))
            db.session.add(collection)
            db.session.commit()
            return "添加收藏成功！"
        except Exception as e:
            db.session.rollback()
            print(e)
            return "添加收藏失败！"


@app.route('/user/food_information', methods=['POST'])
def food_information():
    if request.method == "POST":
        food_id = request.form.get("food_id")
        food_id1 = Food.query.filter_by(food_id=int(food_id)).first()
        if food_id1 is None:
            print(-1)
            return "查找失败，数据库中无此食物！"
        temp = {}
        try:
            temp["food_id"] = food_id1.food_id
            temp["food_name"] = food_id1.food_name
            temp["food_loc"] = food_id1.food_loc
            temp["food_type"] = food_id1.food_type
            temp["food_src"] = food_id1.food_src
            temp["food_likes_num"] = food_id1.food_likes_num
            return temp
        except Exception as e:
            db.session.rollback()
            print(e)
            return "查找失败！"


if __name__ == '__main__':
    app.run()
