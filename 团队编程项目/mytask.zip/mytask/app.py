from flask import Flask, request
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate


app = Flask(__name__)

# 配置信息
HOSTNAME = "127.0.0.1"
PORT = 3306
USERNAME = "root"
PASSWORD = "123456"
DATABASE = "food"
app.config[
    'SQLALCHEMY_DATABASE_URI'] = f"mysql+pymysql://{USERNAME}:{PASSWORD}@{HOSTNAME}:{PORT}/{DATABASE}?charset=utf8mb4"

# 在app.config中设置好连接数据库的信息
# 然后再sqlalchemy(app)中创建一个db对象，他会自动读取连接数据库的配置信息
db = SQLAlchemy(app)
migrate = Migrate(app, db)

# ORM模型映射成表的三步
# 1. flask db init：这步只需要执行一次
# 2. flask db migrate：识别ORM模型的改变，生成迁移脚本
# 3. flask db upgrade：运行迁移脚本，同步到数据库中


class Food(db.Model):
    __tablename__ = "food"
    food_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    # varchar, null=0
    food_name = db.Column(db.String(20), nullable=False)
    food_loc = db.Column(db.String(100), nullable=False)
    food_type = db.Column(db.Integer, default=0)
    food_src = db.Column(db.String(100))
    food_likes_num = db.Column(db.Integer, default=0)


class Comments(db.Model):
    __tablename__ = "comments"
    # 外键
    food_id = db.Column(db.Integer, db.ForeignKey("food.food_id"), primary_key=True)
    comments = db.Column(db.Text,nullable=False)

# user = User(username="法外狂徒张三", password='111111')
# sql: insert user(username, password) values('法外狂徒张三', '111111');


class User(db.Model):
    __tablename__ = "user"
    user_name = db.Column(db.String(20), primary_key=True)
    user_account = db.Column(db.String(20),nullable=False)
    user_password = db.Column(db.String(30), nullable=False)


class Tag(db.Model):
    __tablename__ = "Tag"
    # 添加外键
    user_name = db.Column(db.String(20), db.ForeignKey("user.user_name"), primary_key=True)
    tag1 = db.Column(db.SmallInteger, default=0)
    tag2 = db.Column(db.SmallInteger, default=0)
    tag3 = db.Column(db.SmallInteger, default=0)
    tag4 = db.Column(db.SmallInteger, default=0)
    tag5 = db.Column(db.SmallInteger, default=0)
    tag6 = db.Column(db.SmallInteger, default=0)
    tag7 = db.Column(db.SmallInteger, default=0)
    tag8 = db.Column(db.SmallInteger, default=0)


class Collection(db.Model):
    __tablename__ = "collection"
    user_name = db.Column(db.String(20), db.ForeignKey("user.user_name"), primary_key=True)
    food_id = db.Column(db.Integer, db.ForeignKey("food.food_id"), primary_key=True)


class Friends(db.Model):
    user_name1 = db.Column(db.String(20), db.ForeignKey("user.user_name"), primary_key=True)
    user_name2 = db.Column(db.String(20), db.ForeignKey("user.user_name"), primary_key=True)
    # db.primary_key(user_name1, user_name2)

#
# with app.app_context():
#     with db.engine.connect() as conn:
#         rs = conn.execute("select 1")
#         print(rs.fetchone())  # (1,)


@app.route('/')
def hello_world():
    return "111"


@app.route('/user/add_account', methods=['POST'])
def user_add_account():
    if request.method == "POST":
        name = request.form.get("username")
        account = request.form.get("account")
        password = request.form.get("password")
        user = User(user_name=name, user_account=account, user_password=password)
        try:
            db.session.add(user)
            db.session.commit()
            print(1)
            return "用户创建成功！"
        except Exception as e:
            db.session.rollback()
            print(-1)
            return "用户创建失败！"


@app.route('/user/add_tag', methods=['POST'])
def user_add_tag():
    if request.method == "POST":
        name = request.form.get("username")
        name1 = User.query.get(name)
        # print(name1)
        if name1 is None:
            print(-1)
            return "tag插入失败，数据库中无此用户！"

        tag_list = request.form.get("tag_list")
        # tag_list1 = []
        tag = Tag(user_name=name, tag1=int(tag_list[1]), tag2=int(tag_list[3]), tag3=int(tag_list[5]), tag4=int(tag_list[7]), tag5=int(tag_list[9]), tag6=int(tag_list[11]), tag7=int(tag_list[13]), tag8=int(tag_list[15]))
        # for i in tag_list:
        #     print(i)
        # print(tag_list)
        try:
            db.session.add(tag)
            db.session.commit()
            print(1)
            return "tag插入成功！"
        except Exception as e:
            db.session.rollback()
            print(-1)
            return "tag插入失败！"




if __name__ == '__main__':
    app.run()